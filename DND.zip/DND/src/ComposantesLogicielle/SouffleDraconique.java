package ComposantesLogicielle;

public class SouffleDraconique {
    private String typeDegat; // Type de dégâts du souffle
    private String formeSouffle; // Forme du souffle (cône, ligne, etc.)
    private int degatsBase; // Dégâts de base du souffle
    private int niveau; // Niveau du sangdragon
    private String couleur; // Couleur du souffle

    public SouffleDraconique(String typeDegat, String formeSouffle, String couleur, int niveau) {
        this.typeDegat = typeDegat;
        this.formeSouffle = formeSouffle;
        this.couleur = couleur;
        this.niveau = niveau;
        this.degatsBase = calculerDegats(niveau); // Dégâts basés sur le niveau
    }

    private int calculerDegats(int niveau) {
        if (niveau >= 16) return 5;
        if (niveau >= 11) return 4;
        if (niveau >= 6) return 3;
        return 2;
    }

    public String getTypeDegat() {
        return typeDegat;
    }

    public String getFormeSouffle() {
        return formeSouffle;
    }

    public String getCouleur() {
        return couleur;
    }

    public int getDegats() {
        return degatsBase;
    }

    public String utiliserSouffle() {
        return String.format("Le sangdragon exhale un %s %s infligeant %dd6 dégâts de %s. Chaque créature dans la zone affectée doit faire un jet de sauvegarde de Constitution (DD 8 + modificateur de Constitution + bonus de maîtrise).", 
                             couleur, formeSouffle, degatsBase, typeDegat);
    }
}
