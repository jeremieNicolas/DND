package ComposantesLogicielle;

import java.util.List;

public class Évolution {
	int bonusMaitrise;
	int nbRages;
	int dégâtsRage;
	
	
	public Évolution(int bonusMaitrise,  int nbRages, int dégâtsRage)
	{
		this.bonusMaitrise = bonusMaitrise;
		this.nbRages = nbRages;
		this.dégâtsRage = dégâtsRage;
	}

	public int getBonusMaitrise() {
		return bonusMaitrise;
	}
	public void setBonusMaitrise(int bonusMaitrise) {
		this.bonusMaitrise = bonusMaitrise;
	}

	public int getNbRages() {
		return nbRages;
	}
	public void setNbRages(int nbRages) {
		this.nbRages = nbRages;
	}
	public int getDégâtsRage() {
		return dégâtsRage;
	}
	public void setDégâtsRage(int dégâtsRage) {
		this.dégâtsRage = dégâtsRage;
	}
	
	
}
