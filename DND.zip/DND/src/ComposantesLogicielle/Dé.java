package ComposantesLogicielle;

import java.util.Random;

public class Dé {
	Random rand;
	
	public int d4()
	{
		return rand.nextInt() % 5;
	}
	public int d6()
	{
		return rand.nextInt() % 7;
	}
	public int d8()
	{
		return rand.nextInt() % 9;
	}
	public int d10()
	{
		return  rand.nextInt() % 11; 
 	}
	public int d12()
	{
		return rand.nextInt() % 13;
	}
	public int d20()
	{
		return rand.nextInt() % 21;
	}
	public int d100()
	{
		return rand.nextInt() % 101;
	}
}
