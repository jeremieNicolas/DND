package ComposantesLogicielle;

public class SouffleDraconiqueFactory {

    public static SouffleDraconique creerSouffle(String typeDragon, int niveau) {
        switch (typeDragon.toLowerCase()) {
            case "noir":
                return new SouffleDraconique("Acide", "Ligne (5x30 pieds)", "Noir", niveau);
            case "bleu":
                return new SouffleDraconique("Électricité", "Ligne (5x30 pieds)", "Bleu", niveau);
            case "vert":
                return new SouffleDraconique("Poison", "Cône (15 pieds)", "Vert", niveau);
            case "rouge":
                return new SouffleDraconique("Feu", "Cône (15 pieds)", "Rouge", niveau);
            case "blanc":
                return new SouffleDraconique("Froid", "Cône (15 pieds)", "Blanc", niveau);
            case "cuivre":
                return new SouffleDraconique("Acide", "Ligne (5x30 pieds)", "Cuivre", niveau);
            case "bronze":
                return new SouffleDraconique("Électricité", "Ligne (5x30 pieds)", "Bronze", niveau);
            case "laiton":
                return new SouffleDraconique("Feu", "Ligne (5x30 pieds)", "Laiton", niveau);
            case "argent":
                return new SouffleDraconique("Froid", "Cône (15 pieds)", "Argent", niveau);
            case "or":
                return new SouffleDraconique("Feu", "Cône (15 pieds)", "Or", niveau);
            default:
                throw new IllegalArgumentException("Type de dragon invalide : " + typeDragon);
        }
    }
}
