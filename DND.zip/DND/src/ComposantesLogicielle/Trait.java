package ComposantesLogicielle;

public class Trait {
	String titre;
	String description;
	
	Trait(){}
	
	public Trait(String titre, String description)
	{
		this.titre = titre;
		this.description = description;
	}
}
