package ComposantesLogicielle;

public class Objet {
	String nomObjet;
	String description;
	
	public Objet(){}
	public Objet(String nomObjet, String description)
	{
		this.nomObjet = nomObjet;
		this.description = description;
	}
	public String getNomObjet() {
		return nomObjet;
	}
	public void setNomObjet(String nomObjet) {
		this.nomObjet = nomObjet;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
