package Classes;

import java.util.ArrayList;
import java.util.List;

import ComposantesLogicielle.Aptitude;
import FeuillePerso.FeuillePersonnage;

public class Barbare extends Classe {
    private List<Aptitude> aptitudes;
    private String voiePrimitive;
    private String totem;
    FeuillePersonnage fp;
    
    public Barbare() {
        this.aptitudes = new ArrayList<>();
        this.déVie = "1D12 par niveau de barbare";
        this.pvNiveau1 = 12 + pvNiveau1 + modifConstit;
    }

    // Méthode pour gérer l'évolution du barbare selon son niveau
    private void appliquerÉvolutionParNiveau(int niveau) {
        switch (niveau) {
            case 2:
                aptitudes.add(new Aptitude("Témérité", "Le barbare peut abandonner toute volonté de se défendre pour attaquer avec une férocité désespérée. Il est avantagé sur tous les jets d'attaque de corps à corps basés sur la Force pendant ce tour, mais toutes les attaques dirigées contre le barbare sont avantagées jusqu'à son prochain tour."));
                aptitudes.add(new Aptitude("Sens du danger", "Avantage sur les jets de sauvegarde de Dextérité contre les dangers qu'il pourrait voir, comme les pièges et les sorts. Ne doit pas être aveuglé, assourdi ou neutralisé."));
                break;
            case 3:
                aptitudes.add(new Aptitude("Voie primitive", "Le barbare choisit entre la voie du Berserker ou du Guerrier totem."));
                if(voiePrimitive.equals("Berserker"))
                {
                	aptitudes.add(new Aptitude("Frénésie", "Peut devenir frénétique pendan sa rage. Peut alorsporter une unique attaque supplémentaire par action bonus lors des tours pendant lesquels il est frénétique. Quand la rage prend fin, gain d'un niveau d'épuisement."));
                }
                else if (voiePrimitive.equals("Guerrier Totémique"))
                {
                	aptitudes.add(new Aptitude("Quêteur spirituel", "Apprend à lancer les sorts Sens animal et commmunication aux animaux, mais seulement sous forme de rituels."));
                	aptitudes.add(new Aptitude("Totem spirituel", "Le barbare doit choisir un totem. Il doit acquérir oufabriquer un objet servant de totem physique. Possible de prendre des caractéristiques de ce totem pour se battre. "));
                	if (totem.equals("Aigle"))
                	{
                		aptitudes.add(new Aptitude("Rage de l'aigle", "Tant que le barbare est enragé et qu'il ne porte pas d'armure lourde, les autres créatures sont désavantagées lors de leurs jets d'attaque d'opportunité à votre encontre. De plus, possible d'utiliser l'action Se précipiter comme action bonus pendant son tour. L'esprit de l'aigle fait du barbare un prédateur qui se déplace sans mal au coeur de la mêlée."));
                	}
                	else if(totem.equals("Loup"))
                	{
                		aptitudes.add(new Aptitude("Rage du loup", "Tant que l'aigle est enragé et qu'il n'a pas d'armure lourde, les autres créatures sont désavantagées lors de leurs jets d'attaque d'opportunité à l'encontre du barbare. De plus, le barbare peut utiliser l'action se précipiter comme une action bonus à son tour. L'esprit de l'aigle fait du barbare un prédateur qui se déplace sans mal au coeur de la mêlée."));
                	}
                	else if(totem.equals("Ours"))
                	{
                		aptitudes.add(new Aptitude("Rage de l'ours", "Quand l'ours est enragé, il est résistant à tous les dégâts sauf les dégâts physiques. L'esprit de l'ours le rend assez fort pour résister à n'importe quel châtiment."));
                	}
                }
                break;
            case 4:
                aptitudes.add(new Aptitude("Amélioration de caractéristique", "Gain d'un bonus de +2 ou deux bonus de +1 aux caractéristiques. Cette aptitude ne permet pas de dépasser 20 dans une caractéristique."));
                break;
            case 5:
                aptitudes.add(new Aptitude("Attaque supplémentaire", "Le barbare peut attaquer deux fois au lieu d'une pendant son tour."));
                break;
            case 6:
            	if (voiePrimitive.equals("Berserker"))
            	{
            		aptitudes.add(new Aptitude("Rage aveugle", "Ne peut plus être terrorisé ou charmé pendant la rage. Si déjà terrorisé ou charmé lorsqu'il rage, l'effet est suspendu le temps de la rage."));
            	}
            	else if (voiePrimitive.equals("Guerrier Totémique"))
            	{
            		if (totem == "Aigle")
                	{
                		aptitudes.add(new Aptitude("Aspect de la bête", "Le barbare hérite de l'acuité visuelle de l'aigle. Sa vision est excellente dans un rayon d'un kilomètre et demi et il distingue les menus détails comme si ce qu'il observait se trouvait dans un rayon de 30 mètres. De plus, la faible luminosité ne le désavantage pas lors des test de Sagesse (perception)."));
                	}
                	else if(totem == "Loup")
                	{
                		aptitudes.add(new Aptitude("Aspect de la bête", "Le barbare acquiert le sens du loup en chasse. Il sait suivre la piste d'une créature en se déplaçant à une vitesse rapide et se déplace discrètement même à sa vitesse normale."));
                	}
                	else if(totem == "Ours")
                	{
                		aptitudes.add(new Aptitude("Aspect de la bête", "Le barbare obtient la puissance de l'ours. Sa capacité de charge double, y compris les charges maximales qu'il peut transporter et soulever) et il est avantagé sur less tests de force destinés à pousser, tirer, soulever ou briser un objet."));
                	}
            	}
            	break;
            case 7:
                aptitudes.add(new Aptitude("Instinct sauvage", "Le barbare est avantagé sur les jets d'initiative et peut agir normalement pendant un premier tour s'il devient enragé, même s'il est surpris."));
                break;
            case 8:
                aptitudes.add(new Aptitude("Amélioration de caractéristique", "Gain d'un bonus de +2 ou deux bonus de +1 aux caractéristiques. Cette aptitude ne permet pas de dépasser 20 dans une caractéristique."));
                break;
            case 9:
                aptitudes.add(new Aptitude("Critique brutal", "Le barbare peut lancer un dé de dégâts supplémentaires lors de la détermination des dégâts supplémentaires causés par un coup critique en attaque de corps à corps."));
                break;
            case 10:
            	if (voiePrimitive.equals("Berserker"))
            	{
            		aptitudes.add(new Aptitude("Présence intimidante", "Peut utiliser son action pour terroriser un personnage dans un rayon de 9 mètres. Si la créature le voit ou l'entend, doit réussir un jet de sauvegarde de sagesse (8 + bonus de maitrise + modificateur charisme). Sinon, terrorisée jusqu'à son prochain tour. Effet prend fin si la créature termine son tour en ne voyant plus le barbare ou si elle se trouve a plus de 18 mètres. Si la créature réussit son jet, le barbare ne peut plus utiliser sa compétence pendant 24 heures."));
            		aptitudes.add(new Aptitude("Marcheur spirituel", "Le barbare peut lancer le sort \"Communion avec la nature\", mais seulement sous forme de rituel. Une version spirituelle de l'esprit totémique ou de l'aspect de la bête qu'il a choisi apparaît alors pour lui transmettre l'information demandée. "));
            	}
            	break;
            case 11:
                aptitudes.add(new Aptitude("Rage implacable", "Si le barbare se retrouve à 0 pv en combat mais ne meurt pas, il peut tenter un jet de constitution (DD10) pour rester à 1 pv. Le DD augmente de 5 après chaque utilisation."));
                break;
            case 12:
                aptitudes.add(new Aptitude("Amélioration de caractéristique", "Gain d'un bonus de +2 ou deux bonus de +1 aux caractéristiques. Cette aptitude ne permet pas de dépasser 20 dans une caractéristique."));
                break;
            case 13:
                aptitudes.add(new Aptitude("Critique brutal", "Le barbare peut lancer deux dés de dégâts supplémentaires lors de la détermination des dégâts supplémentaires causés par un coup critique en attaque de corps à corps."));
                break;
            case 14 :
            	if (voiePrimitive.equals("Berserker"))
            	{
            		aptitudes.add(new Aptitude("Représailles", "Si le barbare subit des dégâts venant d'une créature étant dans un rayon de 1,5 mètre, possible d'utiliser réaction pour attaquer cette créature en représailles."));
            		
            		//Choic animal totem
            	}
            	break;
            case 15:
                aptitudes.add(new Aptitude("Rage ininterrompue", "La rage du barbare prend fin uniquement s'il perd conscience ou choisit d'y mettre fin."));
                break;
            case 16:
                aptitudes.add(new Aptitude("Amélioration de caractéristique", "Gain d'un bonus de +2 ou deux bonus de +1 aux caractéristiques. Cette aptitude ne permet pas de dépasser 20 dans une caractéristique."));
                break;
            case 17:
                aptitudes.add(new Aptitude("Critique brutal", "Le barbare peut lancer trois dés de dégâts supplémentaires lors de la détermination des dégâts supplémentaires causés par un coup critique en attaque de corps à corps."));
                break;
            case 18:
                aptitudes.add(new Aptitude("Puissance indomptable", "Si le résultat d'un test de Force est inférieur à la valeur de Force du barbare, il peut utiliser sa valeur de Force à la place du résultat."));
                break;
            case 19:
                aptitudes.add(new Aptitude("Amélioration de caractéristique", "Gain d'un bonus de +2 ou deux bonus de +1 aux caractéristiques. Cette aptitude ne permet pas de dépasser 20 dans une caractéristique."));
                break;
            case 20:
                aptitudes.add(new Aptitude("Champion primitif", "La Force et la Constitution du barbare augmentent de 4, et le maximum pour ces caractéristiques devient 24."));
                break;
            default:
                // Aucun changement pour ce niveau
                break;
        }
    }

    private void choixAptitude(String choix) {
		if (choix == "Aigle")
		{
			aptitudes.add(new Aptitude("Harmonisation totémique", "Tant qu'il est enragé, l'aigle bénéficie d'une vitesse de vol égale à la vitesse de base au sol actuelle, mais sur une très courte période. Si le barbare termine son tours dans les airs et que rien ne le retient, il tombe au sol."));
		}
		else if (choix == "Loup")
		{
			aptitudes.add(new Aptitude("Harmonisation totémique", "Tant qu'il est enragé, le barbare peut utiliser une action bonus pendant so tour pour faire tomber à terre une créature de taille Grande ou inférieure au moment où il la touche avec une attaque effectuée avec une arme de corps à corps."));
		}
		else if (choix == "Ours")
		{
			aptitudes.add(new Aptitude("Harmonisation totémique", "Tant qu'il est enragé, toute créature hostile à son égard et située dans un rayon de 1,50 mètre autour de lui est désavantagée lors de ses jets d'attaque contre les cibles autres que le barbare ou qu'un autre personnage doté de cette aptitude. L'ennemi est immunisé contre cet effet s'il est incapable de voir ou d'entendre le barbare ou s'il est insensible à la terreur."));
		}
		
	}

	// Méthode pour obtenir les aptitudes débloquées par niveau
    public List<Aptitude> getÉvolutionParNiveau(int niveau) {
        appliquerÉvolutionParNiveau(niveau);
        return this.aptitudes;
    }
}
