package Classes;
import java.util.List;
import java.util.Random;

import ComposantesLogicielle.Aptitude;
import ComposantesLogicielle.Dé;
import ComposantesLogicielle.Évolution;
import FeuillePerso.Competence;

public abstract class Classe {
	
	Évolution tableauÉvolution;
	String déVie;
	int pvNiveau1;
	int pvNiveauxSupérieurs;
	List<String> maitrisesArmures;
	List<String> maitrisesArmes;
	List<String> maitrisesOutils;
	List<Competence> jetsSauvegardes;
	List<Competence> maitrisesCompetencesAChoisir;
	List<Aptitude> aptitudes;
	
	Classe(){}
	
	Classe(Évolution tableauÉvolution, String déVie, int pvNiveau1, int pvNiveauxSupérieurs, List<String> maitrisesArmures, List<String> maitrisesArmes,	List<String> maitrisesOutils,
	List<Competence> jetsSauvegardes, List<Competence> maitrisesCompetencesAChoisir, List<Aptitude> aptitudes)
	{
		this.tableauÉvolution = tableauÉvolution;
		this.déVie = déVie;
		this.pvNiveau1 = pvNiveau1;
		this.pvNiveauxSupérieurs = pvNiveauxSupérieurs;
		this.maitrisesArmures = maitrisesArmures;
		this.maitrisesArmes = maitrisesArmes;
		this.maitrisesOutils = maitrisesOutils;
		this.jetsSauvegardes = jetsSauvegardes;
		this.maitrisesCompetencesAChoisir = maitrisesCompetencesAChoisir;
		this.aptitudes = aptitudes;
	}

	public Évolution getTableauÉvolution() {
		return tableauÉvolution;
	}

	public void setTableauÉvolution(Évolution tableauÉvolution) {
		this.tableauÉvolution = tableauÉvolution;
	}

	public String getDéVie() {
		return déVie;
	}

	public void setDéVie(String déVie) {
		this.déVie = déVie;
	}

	public int getPvNiveau1() {
		return pvNiveau1;
	}

	public void setPvNiveau1(int pvNiveau1) {
		this.pvNiveau1 = pvNiveau1;
	}

	public int getPvNiveauxSupérieurs() {
		return pvNiveauxSupérieurs;
	}

	public void setPvNiveauxSupérieurs(int pvNiveauxSupérieurs) {
		this.pvNiveauxSupérieurs = pvNiveauxSupérieurs;
	}

	public List<String> getMaitrisesArmures() {
		return maitrisesArmures;
	}

	public void setMaitrisesArmures(List<String> maitrisesArmures) {
		this.maitrisesArmures = maitrisesArmures;
	}

	public List<String> getMaitrisesArmes() {
		return maitrisesArmes;
	}

	public void setMaitrisesArmes(List<String> maitrisesArmes) {
		this.maitrisesArmes = maitrisesArmes;
	}

	public List<String> getMaitrisesOutils() {
		return maitrisesOutils;
	}

	public void setMaitrisesOutils(List<String> maitrisesOutils) {
		this.maitrisesOutils = maitrisesOutils;
	}

	public List<Competence> getJetsSauvegardes() {
		return jetsSauvegardes;
	}

	public void setJetsSauvegardes(List<Competence> jetsSauvegardes) {
		this.jetsSauvegardes = jetsSauvegardes;
	}

	public List<Competence> getMaitrisesCompetencesAChoisir() {
		return maitrisesCompetencesAChoisir;
	}

	public void setMaitrisesCompetencesAChoisir(List<Competence> maitrisesCompetencesAChoisir) {
		this.maitrisesCompetencesAChoisir = maitrisesCompetencesAChoisir;
	}

	public List<Aptitude> getAptitudes() {
		return aptitudes;
	}

	public void setAptitudes(List<Aptitude> aptitudes) {
		this.aptitudes = aptitudes;
	}
}