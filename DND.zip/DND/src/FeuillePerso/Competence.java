package FeuillePerso;

public class Competence {
	boolean maitrise;
	String nom;
	int modificateur;
	
	Competence()
	{}
	Competence(boolean maitrise, String nom, int modificateur)
	{
		this.maitrise = maitrise;
		this.nom = nom;
		this.modificateur = modificateur; 
	}
	public boolean isMaitrise() {
		return maitrise;
	}
	public void setMaitrise(boolean maitrise) {
		this.maitrise = maitrise;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getModificateur() {
		return modificateur;
	}
	public void setModificateur(int modificateur) {
		this.modificateur = modificateur;
	}
	
	
}
