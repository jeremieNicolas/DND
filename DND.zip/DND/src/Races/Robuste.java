package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class Robuste extends Halfelin{

	private List<Trait> listeTraits;
	public Robuste()
	{
		super();
		this.listeTraits  = getTraitsRobuste();
	}
	private List<Trait> getTraitsRobuste() {
        // Récupère les traits de base des Halfelins
        List<Trait> traitsRobuste = super.getListeTraits();

        // Ajoute les traits spécifiques aux Pieds-Légers
        traitsRobuste.addAll(Arrays.asList(
        		new Trait("Augmentation de caractéristique", "Votre charisme augmente de 1"),
        		new Trait("Résilience des robustes","Vous êtes avantagé lors des jets de sauvegarde contre le poison et êtes résistant aux dégâts de poison.")
        		));

        return traitsRobuste;
    }
}
