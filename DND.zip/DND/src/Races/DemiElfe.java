package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class DemiElfe extends Race {
	
	public DemiElfe()
	{
		this.nomRace = "Demi-elfe";
        this.listeTraits = getTraitsDemiElfe();
	}
	
	private List<Trait> getTraitsDemiElfe()
	{
		return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La valeur de Charisme augmente de 2. La valeur de deux caractéristiques au choix augmentent de 1."),
					new Trait("Âge", "Les demi-elfes grandissent au même rythme que les humains et deviennent matures vers 20 ans. Par contre, ils vivent bien plus longtemps que les humains et il n'est pas rare qu'ils dépassent les 180 ans."),
					new Trait("Alignement", "Les demi-elfes partagent les tendances chaotiques de leurs ancêtres elfiques. Ils apprécient leur liberté et la créativité et n'ont aucune envie de suivre un leader ou d'en devenir un eux-mêmes. Ils n'apprécient pas qu'on leur impose des règles ou qu'on attende des choses d'eux et se montrent parfois indignes de confiance ou tout au moins imprévisibles."),
					new Trait("Taille", "Les demi-elfes sont de taille similaire aux humains. Ils font entre 150 et 180 centimètres et sont de taille Moyenne."),
					new Trait("Vitesse", "Votre vitesse de base au sol est de 9 mètres."),
					new Trait("Vision dans le noir", "Grâce à son sang elfique, le demi-elfe a hérité d'une vision supérieiure dans l'obscurité et dans la lumière faible. Dans un rayon de 18 mètres, vous pouvez voir dans une zone de lumière faible comme s'il s'agissait d'une lumière vive et dans l'obscurité comme s'il s'agissait d'une lumière faible. Toutefois, l'elfe ne distingue pas les douleurs dans l'obscurité, seulement des  nuances de gris."),
					new Trait("Ascendance féérique","L'elfe est avantagé sur les jets de sauvegarde contre l'effet charmé et ne peut pas être contraint à dormir par la magie."),
					new Trait("Polyvalence", "Gain de la maîtrise de deux compétences au choix."),
					new Trait("Langues", "L'elfe peut parler, lire et écrire le commun, l'elfique et une autre langue au choix.")
				);
	}
}
