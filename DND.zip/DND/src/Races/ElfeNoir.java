package Races;
import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class ElfeNoir extends Elfe{
	public ElfeNoir()
	{
		super();
		this.nomRace = "Elfe noir";
		this.listeTraits = getTraitsElfeNoir();
	}

	private List<Trait> getTraitsElfeNoir() {
		List<Trait> traitsElfeNoir = super.getListeTraits();
		traitsElfeNoir.addAll(
				Arrays.asList(new Trait("Augmentation de caractéristiques", "Votre valeur de charisme augmente de 1."),
				new Trait("Sensibilité à la lumière du soleil", "Vous êtes désavantagé lors des jets d'attaque et des tests de Sagesse (Perception) basés sur la vue lorsque vous, votre cible ou ce que vous tentez de percevoir se retrouve sous la lumière direct du soleil."),
				new Trait("Magie drow", "Vous connaissez le tour de magie 'Lumières dansantes'. Au niveau 3, vous pouvez aussi lancer 'Ténèbres'. Vous devez terminer un long repos avant de pouvoir relancer ce sort ainsi. Vous utilisez le Charisme comme caractérsitique ncantatoire pour tous ces sorts."),
				new Trait("Entraînement aux armes drows", "Vous maîtrisez les rapières, les épées courtes et les arbalètes de poing.")
				));
		return null;
	}
}