package Races;

import java.util.Arrays;
import java.util.List;
import ComposantesLogicielle.Trait;

public class PiedLéger extends Halfelin {

    public PiedLéger() {
        super();
        this.nomsMasculins = Arrays.asList("Alton", "Cade", "Corrin", "Eldon", "Errich", "Finnan", "Garret", "Lindal", "Lyle", "Merric", "Milo", "Osborn", "Perrin", "Reed", "Roscoe", "Wellby");
        this.nomsFéminins = Arrays.asList("Andry", "Bree", "Callie", "Carry", "Cora", "Euphemia", "Jillian", "Kithri", "Lavinia", "Lidda", "Merla", "Nedda", "Paela", "Portia", "Seraphina", "Shaena", "Verna");
        this.listeTraits = getTraitsPiedLéger();
    }

    private List<Trait> getTraitsPiedLéger() {
        // Récupère les traits de base des Halfelins
        List<Trait> traitsPiedLéger = super.getListeTraits();

        // Ajoute les traits spécifiques aux Pieds-Légers
        traitsPiedLéger.addAll(Arrays.asList(
            new Trait("Augmentation de caractéristiques", "Votre valeur de Charisme augmente de 1."),
            new Trait("Discrétion naturelle", "Vous pouvez tenter de vous cacher même quand seulement dissimulé par une créature d'au moins une catégorie de taille de plus que vous.")
        ));

        return traitsPiedLéger;
    }
}
