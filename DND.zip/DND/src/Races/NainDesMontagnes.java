package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class NainDesMontagnes extends Nain{
	private List<Trait> getTraitsNainDesMontagnes()
	{
		List<Trait> traitsNainDesMontagnes = super.getListeTraits();
		traitsNainDesMontagnes.addAll(Arrays.asList(
				new Trait("Augmentation de caractéristiques", "Votre valeur de force augmente de 2."),
				new Trait("Formation au port des armures naines", "Le nain des montagnes maitrise les armures légères et intermédiaires.")
			));
		return traitsNainDesMontagnes;
	}
}

