package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class Elfe extends Race {
	
	public Elfe()
	{
		this.nomRace = "Elfe";
		this.nomsEnfant = Arrays.asList("Ara", "Beiro", "Carric");
        this.nomsMasculins = Arrays.asList("Adran", "Aelar", "Aramil");
        this.nomsFéminins = Arrays.asList("Adrie", "Althaea", "Anastrianna");
        this.nomsFamille = Arrays.asList("Amakiir", "Galanodel", "Liadon");
        this.listeTraits = getTraitsElfe();
	}
	
	private List<Trait> getTraitsElfe()
	{
		return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La valeur de Dextérité augmente de 1."),
					new Trait("Âge", "Bien que les elfes atteignent leur maturité physique environ au même âge que les humains, ils considèrent qu'être un adulte dépasse ce simple aspect et prend en compte l'expérience de la vie. Un elfe se déclare généralement adulte vers 100 ans et choisit à ce moment son nom d'adulte. Les elfes peuvent vivre jusqu'à 750 ans."),
					new Trait("Alignement", "Les elfes sont amoureux de la liberté, de la diversité et de leur liberté d'expression. C'est pourquoi ils tendent fortement vers les aspects les plus modérés du chaos. La liberté des autres a autant de valeur à leurs yeux que la leur et ils sont plutôt enclins à faire le bien."),
					new Trait("Taille", "Les elfes mesurent généralement entre 1,50 et 1,80 mètres et sont minces. Ils sont de taille moyenne."),
					new Trait("Vitesse", "La vitesse de base d'un elfe au sol est de 9 mètres."),
					new Trait("Vision dans le noir", "Habitué à la pénombre des forêts et à au ciel nocturne, l'efe a une vision supérieure dans l'obscurité et dans la lumière faible. Dans un rayon de 18 mètres, il peut voir dans une zone de lumière faible comme s'il s'agissait d'une lumière vive et dans l'obscurité comme s'il s'agissait d'une lumière faible. Il ne peut toutefois pas voir les couleurs dans l'obscurité, seulement des nuances de gris."),
					new Trait("Sens aiguisés", "L'elfe maitrise la compétence Perception."),
					new Trait("Ascendance féérique", "L'elfe est avantagé sur les jets de sauvegarde contre l'effet Charmé et ne peut être contraint à dormir par la magie."),
					new Trait("Transe", "Les elfes n'ont pas besoin de dormir. À la place, ils passent 4 heures par jour dans un état de méditation profonde, tout en restant semi-conscients. Pendant cette méditation, l'elfe peut faire une sorte de rêve. Ces rêves sont en réalité des exercices mentaux qui sont devenus réflexes après plusieurs années de pratique. En se reposant ainsi, il bénéficie des mêmes avantages conférés à un humain par 8 heures de sommeil."),
					new Trait("Langues", "L'elfe peut parler, lire et écrire le commun et l'elfique. Le langage des elfes est fluide, avec des intonations subtiles et une grammaire élaborée. La littérature des elfes est riche et variée et leurs chansons et poèmes sont populaires parmi les autres races. De nombreux bardes apprennent à parler elfe afin de pouvoir ajouter des balades elfiques à leur répertoire.")
				);
	}
}
