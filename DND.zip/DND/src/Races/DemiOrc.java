package Races;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class DemiOrc extends Race{
	private List<Trait> getTraitsDemiOrc()
	{
		List<Trait> traitsDemiOrc = new ArrayList<Trait>();
		
		traitsDemiOrc.addAll(Arrays.asList(
			new Trait("Augmentation de caractéristiques", "Votre valeur de force augmente de 2  et votre valeur de constitution de 1"),
			new Trait("Âge", "Les demi-orcs deviennent matures un peu plus vite que les humains. Ils sont considérés comme adultes vers 14 ans. Par contre, il vieillissent plus vite et vivent rarement plus de 75 ans."),
			new Trait("Alignement", "Les demi-orcs héritent d'une tendance au chaos de leur parent orc et ils ne sont pas forcément enclins au bien. Les demi-orcs élevés parmi les orcs et qui souhaitent continuer de vivre avec eux ont généralement un alignement Mauvais."),
			new Trait("Taille", "Les demi-orcs sont plus larges et plus corpulents que les humains. Les plus petits d'entre eux mesurent entre 1,50 mètre et les plus grands dépassent facilement 1,80 mètre. Ils sont de taille moyenne."),
			new Trait("Vision dans le noir", "Grâce à votre sang Orc, le demi-orc a hérité d'une vision supérieure dans l'obscurité et dans la lumière faible. Il ne distingue toutefois pas les couleurs dans l'obscurité, seulement des nuances de gris."),
			new Trait("Menaçant", "Maitrise de la compétence Intimidation."),
			new Trait("Acharnement", "Lorsque le demi-orc se retrouve à 0 point de vie mais qu'il n'est pas tué sur le coup, il peut choisir d'être réduit à 1 point de vie. Il ne peut réutiliser cette aptitude tant qu'il n'a pas fait un repos long."),
			new Trait("Sauvagerie", "Lors de la réussite d'un coup critique avec une attaque de corps à corps, il peut relancer un des dés de dégâts de l'arme et ajouter son résultat aux dégâts supplémentaires du coup critique."),
			new Trait("Langues", "Le demi-orc peut lire, parler et écrire le commun et l'orc. La langue Orc a une sonorité dure et certains sons évoquent des grincements. Les orcs n'ont pas d'alphabet propre et utilisent donc l'alphabet nain.")
				));
		return traitsDemiOrc;
	}
}


