package Races;
import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

class Gnome extends Race{
public Gnome()
	{
		this.nomRace = "Gnome";
		this.nomsMasculins = Arrays.asList("Alston", "Alvyn", "Boddynock", "Brocc","Burgell", "Dimble", "Eldon", "Erky", "Fronkin", "Frug", "Gerbo", "Gimble", "Glim", "Jebeddo", "Kellen", "Namfoodle", "Orryn", "Roondar","Seebo", "Sindri", "Warryn", "Wrenn", "Zook");
		this.nomsFéminins = Arrays.asList("Bimpnottine", "Breena", "Caramip", "Carline", "Donella", "Duvamil", "Ella", "Ellyjobell", "Ellywick", "Lilli", "Loopmottine", "Lorilla", "Mardnab", "Nissa", "Nyx", "Oda", "Orla", "Roywyn", "Shamil", "Tana", "Waywocket", "Zanna");
		List<String> nomClans = Arrays.asList("Beren", "Daergel", "Folkor", "Garrick", "Nackle", "Murnig", "Ningel", "Raulnor", "Scheppen", "Timbers", "Turen");
		List<String> surnoms = Arrays.asList("Brillegemme", "Canardboiteux", "Cendrefoyer", "Clapebière", "Doubleboucle", "Fnipper", "Furet", "Ku", "Manteau", "Nim", "Piquepâte", "Pock", "Qu'unechaussure");
		this.listeTraits = getTraitsHalfelin();
	}
		private List<Trait> getTraitsHalfelin()
		{
			return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La valeur d'intelligence augmente de 2."),
					new Trait("Âge", "Les gnomes grandissent au même rythme que les humains. On estime qu'ils deviennent adultes vers 40 ans. Ils peuvent vivre de 350 ans à presque 500 ans."),
					new Trait("Alignement", "Les gnomes sont généralement attirés par le bien. Ceux qui sont attirés par la loi sont ds sages, des ingénieurs, ds chercheurs, des érudits, des enquêteurs ou des inventeurs. Ceux qui sont plus attirés par le chaos deviennent ménestrels, arnaqueurs, vagabonds ou bijoutiers spécialisés en bijoux fantaisie. Les gnomesont bon coeur et même les arnaqueurs sont finalement plus taquins que mal intentionnés."),
					new Trait("Taille", "Les gnomes mesurent entre 90 et 120 centimètres et pèsent en moyenne une vingtaine de kilos. Ils sont de taille petite."),
					new Trait("Vitesse", "La vitesse des gnomes au sol est de 7,50 mètres."),
					new Trait("Vision dans le noir", "Habitué à la vie souterraine, le gnome a une vision supérieure dans l'obscurité et la lumière faible. Dans un rayon de 18 mètres, il peut voir dans une zone de lumière faible comme s'il s'agissait de lumière vive et dans l'obscurité comme s'il s'agissait de lumière faible. Par contre, il ne distingue pas les couleurs dans l'obscurité, seulement des nuances de gris."),
					new Trait("Langues", "Le gnome peut parler, lire et écrire le commun et le gnome. Le gnome utilise l'alphabet nain. Les gnomes sont renommés pour leurs traités techniques et leurs catalogues de connaissances sur la nature.")
					);					
		}
}