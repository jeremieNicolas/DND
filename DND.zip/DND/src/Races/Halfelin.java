package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class Halfelin extends Race{
	public Halfelin()
	{
		this.nomRace = "Halfelin";
		this.nomsMasculins = Arrays.asList("Alton","Cade","Corrin", "Eldon", "Errich", "Finnan", "Garret", "Lindal", "Lyle","Merric", "Milo", "Osborn", "Perrin", "Reed","Roscoe","Wellby");
		this.nomsFéminins = Arrays.asList("Andry", "Bree", "Callie", "Carry", "Cora","Euphemia","Jillian","Kithri","Lavinia","Lidda","Merla","Nedda","Paela","Portia", "Seraphina", "Shaena", "Verna");
		this.listeTraits = getTraitsHalfelin();
	}
		private List<Trait> getTraitsHalfelin()
		{
			return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La dextérité augmente de 2"),
					new Trait("Âge", "Un halfelin atteint la maturité vers 20 ans et vit généralement 150 ans"),
					new Trait("Alignement", "La majorité des halfelins sont d'alignement Loyal bon. Ce sont par nature des êtres qui ont bon coeur et qui sont gentils. Ils détestent voir les autres créatures souffrir et ne tolèrent pas l'oppression. Ils sont aussi très organisés et respectueux des traditions. Ils se reposent beaucoup sur leur communauté et le confort apporté par leur tradition."),
					new Trait("Taille", "D'une taille moyenne de 90 centimètres, les halfelins pèsent environ 20 kilos. Ils sont de taille Petite."),
					new Trait("Vitesse", "L'Halfelin a une vitesse de base de 7,50 mètres."),
					new Trait("Chanceux", "Lorsque l'halfelin fait un 1 avec le d20 d'un jet d'attaque, d'un test de caractéristique ou d'un jet de sauvegarde, il peut relancer le dé. Il doit toutefois utiliser le nouveau résultat du jet."),
					new Trait("Brave", "Avantage sur les jets de sauvegarde contre la terreur."),
					new Trait("Agilité halfeline", "L'Halfelin peut traverser n'importe quel emplacement occupé par une créature d'au moins une catégorie de taille de plus que lui."),
					new Trait("Langues", "Peut parler, lire et écrire le commun et le halfelin. Bien que la langue des halfelins n'ait rien d'un secret, ils n'aiment pas l'Apprendre aux autres. Ils écrivent très peu et n'ont donc pas énormément de livres. Keur tradition orale est par contre très riches. Presque tous les halfelins parlent le commun, ce qui leur permet de converser avec les gens qui habitent sur les mêmes territoires qu'eux ou dont ils traversent les terres.")
					);
					
	}
}

