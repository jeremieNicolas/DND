package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class Humain extends Race {
	
	public Humain()
	{
		this.nomRace = "Humain";
		this.nomsEnfant = Arrays.asList("Ara", "Beiro", "Carric");
        this.nomsMasculins = Arrays.asList("Adran", "Aelar", "Aramil");
        this.nomsFéminins = Arrays.asList("Adrie", "Althaea", "Anastrianna");
        this.nomsFamille = Arrays.asList("Amakiir", "Galanodel", "Liadon");
        this.listeTraits = getTraitsHumain();
	}
	
	private List<Trait> getTraitsHumain()
	{
		return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La valeur de toutes les caractésistiques augmente de 1."),
					new Trait("Âge", "Les humaisn deviennent adultes à la fin de l'adolescence et vivent moins d'un siècle."),
					new Trait("Alignement", "Les humains ne sont pas naturellement attirés vers un certain type d'alignement. On trouve parmi eux le meilleur comme le pire."),
					new Trait("Taille", "Les humains ont des tailles et des carrures très variées. Ils peuvent faire 1,50 mètre comme plus de 1,80 mètre. Ils sont considérés comme une créature de taille moyenne, peu importe leur taille, carrure ou poids."),
					new Trait("Vitesse", "La vitesse de base d'un humain au sol est de 9 mètres."),
					new Trait("Langues", "L'humain peut parler, lire et écrire le commun et une langue supplémentaire au choix. Les humains apprennent généralement la langue des peuples qu'ils fréquentent, même s'il s'agit parfois d'obscures dialectes. Ils aiment parsemer leur langue d'expressions musicales elfiques, des citations militaires naines, etc. ")
				);
	}
}
