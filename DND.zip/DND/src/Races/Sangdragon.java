package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.SouffleDraconique;
import ComposantesLogicielle.SouffleDraconiqueFactory;
import ComposantesLogicielle.Trait;

public class Sangdragon extends Race {
    private SouffleDraconique souffleDraconique;

    // Utilisation de la factory pour initialiser le souffle draconique
    public Sangdragon(String typeDragon, int niveau) {
        this.nomRace = "Sangdragon";
        this.souffleDraconique = SouffleDraconiqueFactory.creerSouffle(typeDragon, niveau);
        this.nomsMasculins = Arrays.asList("Arjhan", "Balasar", "Bharash", "Donaar", "Ghesh", "Heskan", "Kriv", "Medrash", "Méhen", "Nadarr", "Pandjed", "Patrin", "Rhogar", "Shamash", "Shedinn", "Tarhun", "Torinn");
        this.nomsFéminins = Arrays.asList("Akra", "Biri", "Daar", "Faridch", "Harann", "Havilar", "Jheri", "Kava", "Korinn", "Mishann", "Nala", "Perra", "Raiann", "Sora", "Surina", "Thava", "Uadjit");
        this.nomsEnfant = Arrays.asList("Grimpeur", "Mordeur-de-Bouclier", "Perce-Oreille", "Dévot", "Sauteur", "Zélé");
        this.listeTraits = getTraitsSangdragon();
    }

    // Définition des traits du Sangdragon
    private List<Trait> getTraitsSangdragon() {
        return Arrays.asList(
                new Trait("Augmentation de caractéristique", "La valeur de force augmente de 2 et le charisme de 1."),
                new Trait("Âge", "Les sangdragons grandissent vite. Ils sont considérés adultes vers 15 ans et vivent environ 80 ans."),
                new Trait("Alignement", "Les sangdragons préfèrent généralement les extrêmes et choisissent consciemment leur camp dans la guerre cosmique."),
                new Trait("Taille", "Les sangdragons sont plus grands et lourds que les humains, de taille Moyenne."),
                new Trait("Vitesse", "La vitesse de base du sangdragon est de 9 mètres."),
                new Trait("Souffle", "Le sangdragon peut utiliser une action pour exhaler une vague d'énergie destructrice. Type de dégât : " + souffleDraconique.getTypeDegat() + ", Forme : " + souffleDraconique.getFormeSouffle() + ", Couleur : " + souffleDraconique.getCouleur() + ". La quantité de dégâts augmente avec les niveaux."),
                new Trait("Résistance aux dégâts", "Le sangdragon possède une résistance au type de dégât associé au souffle draconique."),
                new Trait("Langues", "Le Sangdragon peut parler, lire et écrire le commun et le draconique.")
        );
    }
}
