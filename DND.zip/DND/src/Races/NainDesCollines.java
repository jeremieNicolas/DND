package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class NainDesCollines extends Nain{
	private List<Trait> getTraitsNainDesCollines()
	{
		List<Trait> traitsNainDesCollines = super.getListeTraits();
		traitsNainDesCollines.addAll(Arrays.asList(
				new Trait("Augmentation de caractéristiques", "Votre valeur de sagesse augmente de 1."),
				new Trait("Ténacité naine", "Le nombre maximum de points de vie du personnage augmente de 1. Il augmente de 1 à chaque fois que le nain des collines augmente de niveau.")
				));
		return traitsNainDesCollines;
	}
}

