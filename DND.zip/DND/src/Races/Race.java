package Races;

import java.util.List;

import ComposantesLogicielle.Trait;
import FeuillePerso.FeuillePersonnage;

public class Race {
	String nomRace;
	List<String> nomsEnfant;
	List<String> nomsMasculins;
	List<String> nomsFéminins;
	List<String> nomsFamille;
	List<Trait> listeTraits;
	
	public void race()
	{
		
	}
	public void race(String nomRace, List<String> nomsEnfant, List<String> nomsMasculins, List<String> nomsFéminins, List<String> nomsFamille, List<Trait> listeTraits)
	{
		this.nomRace = nomRace;
		this.nomsEnfant = nomsEnfant;
		this.nomsMasculins = nomsMasculins;
		this.nomsFéminins = nomsFéminins;
		this.nomsFamille = nomsFamille;
	}
	public String getNomRace() {
		return nomRace;
	}
	public void setNomRace(String nomRace) {
		this.nomRace = nomRace;
	}
	public List<String> getNomsEnfant() {
		return nomsEnfant;
	}
	public void setNomsEnfant(List<String> nomsEnfant) {
		this.nomsEnfant = nomsEnfant;
	}
	public List<String> getNomsMasculins() {
		return nomsMasculins;
	}
	public void setNomsMasculins(List<String> nomsMasculins) {
		this.nomsMasculins = nomsMasculins;
	}
	public List<String> getNomsFéminins() {
		return nomsFéminins;
	}
	public void setNomsFéminins(List<String> nomsFéminins) {
		this.nomsFéminins = nomsFéminins;
	}
	public List<String> getNomsFamille() {
		return nomsFamille;
	}
	public void setNomsFamille(List<String> nomsFamille) {
		this.nomsFamille = nomsFamille;
	}
	public List<Trait> getListeTraits() {
		return listeTraits;
	}
	public void setListeTraits(List<Trait> listeTraits) {
		this.listeTraits = listeTraits;
	}
	
	
}
