package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class HautElfe extends Elfe {

	public HautElfe() 
	{
		super();
		this.nomRace = "Haut elfe";
		this.listeTraits = getTraitsHautElfe();
	}

	private List<Trait> getTraitsHautElfe() {
		List<Trait> traitsHautElfe = super.getListeTraits();
		traitsHautElfe.addAll(Arrays.asList(
				new Trait("Augmentation de caractéristiques", "Votre valeur d'Intelligence augmente de 1"),
				new Trait("Entraînement aux armes elfiques", "Vous maîtrisez les épées longues, les épées courtes, les arcs longs et les arcs courts."), 
				new Trait("Tour de magie", "Vous connaissez un tour de magie de votre choix parmi la liste de sorts de magicien. Votre caractéristique d'incantation pour ce tour de magie est l'Intelligence."),
				new Trait("Langue supplémentaire", "Vous pouvez lire, parler et écrire une langue supplémentaire au choix.")
				));
		return traitsHautElfe;
	}
	
}
