package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class ElfeSylvestre extends Elfe{
	public ElfeSylvestre() 
	{
		super();
		this.nomRace = "Elfe sylvestre";
		this.listeTraits = getTraitsElfeSylvestre();
	}

	private List<Trait> getTraitsElfeSylvestre() {
		List<Trait> traitsHautElfe = super.getListeTraits();
		traitsHautElfe.addAll(Arrays.asList(
				new Trait("Augmentation de caractéristiques", "Votre valeur de sagesse augmente de 1"),
				new Trait("Entraînement aux armes elfiques", "Vous maîtrisez les épées courtes, les épées longues, les arcs courts et les arcs longs."),
				new Trait("Pied léger", "Votre vitesse de base passe à 10 mètres"),
				new Trait("Cachette naturelle", "Vous pouvez tenter de vous cacher même quand la visibilité n'est que légèrement réduite du fait des frondaisons, d'une forte pluie, de chutes de neige, d'une nappe de brume ou tout autre phénomène naturel.")
				));
		return traitsHautElfe;
	}
}
