package Races;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Objet;
import ComposantesLogicielle.Trait;

public class GnomeDesRoches extends Gnome{
	private List<Trait> getTraitsGnomeDesForêts()
	{
		List<Trait> traitsGnomeDesRoches = super.getListeTraits();
		List<Objet> objetsFabricables = new ArrayList<Objet>();
		traitsGnomeDesRoches.addAll(Arrays.asList(
				 new Trait("Augmentation de caractéristiques", "La valeur de constitution augmente de 1"),
				 new Trait("Connaissances en ingénierie", "Quand le gnome des roches fait un test d'Intelligence(histoire) relatif aux objets magiques, alchimiques ou technologiques, le gnome ajoute le double du bonus de maîtrise au résultat du test au lieu du bonus normal."),
				 new Trait("Bricoleur", "Le gnome des roches maîtrise les outils d'artisans (Outils de bricoleur). Grâce à ces outils, vous pouvez passer une heureet dépenser 10 pièces d'or en matériaux pour construire un mécanisme de taille Très Petite (CA 5, 1 pv). Ce mécanisme cesse de fonctionner au bout de 24 heures (Sauf si le gnome passe une heure à le réparer) ou s'il utilise une action pour le démanteler. Il pourra alors récupérer les matériaux qui ont servi à sa construction. Le gnome des roches peut avoir jusqu'à trois mécanismes en sa posession.")			 
				));
		objetsFabricables.addAll(Arrays.asList(
				 new Objet("Boîte à musique", "Quand elle est ouverte, la boîte à musique joue une mélodie à volume modéré. La boîte redevient silencieuse à la fin de la mélodie ou quand elle est fermée."),
				 new Objet("Briquet", "Ce mécanisme produit une petite flamme qui peut être utilisée pour allumer une bougie, une torche ou un feu de camp.  L'utilisation du briquet coûte une action."),
				 new Objet("Jouet mécanique", "Ce jouet est un animal, un mosntre ou une personne mécanique. Quand il est placé sur le sol, le jouet peut se déplacer de 1,50 mètres d'une direction aléatoire à chacun des tours. Il fait un bruit correspondant à la créature qu'il représente.")
				));
		return traitsGnomeDesRoches;
	}
	
}
