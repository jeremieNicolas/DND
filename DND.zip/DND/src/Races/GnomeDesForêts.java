package Races;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class GnomeDesForêts extends Gnome{
	private List<Trait> getTraitsGnomeDesForêts()
	{
		List<Trait> traitsGnomeDesForêts = super.getListeTraits();
		traitsGnomeDesForêts.addAll(Arrays.asList(
				new Trait("Augmentation de caractéristiques", "La valeur de dextérité augmente de 1"), 
				new Trait("Illusionniste né", "Connait le tour de magie Illusion mineure et utilise l'Intelligence comme caractéristique d'incantation pour le lancer."),
				new Trait("Communication avec les petits animaux", "À l'aide de bruits et de gestes, vous arrivez à ransmettre des concepts simples à des bêtes de taille Petite ou inférieure. Les gnomes des forêts aiment les animaux et ont souvent des écureuils, des blaireaux, des lapins, des taupes, des pics-verts et d'autres créatures comme compagnons.")
				));
		return traitsGnomeDesForêts;
	}
	
}
