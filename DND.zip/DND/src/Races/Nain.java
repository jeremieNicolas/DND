package Races;

import java.util.Arrays;
import java.util.List;

import ComposantesLogicielle.Trait;

public class Nain extends Race {
	
	public Nain()
	{
		this.nomRace = "Nain";
		this.nomsEnfant = Arrays.asList("Ara", "Beiro", "Carric");
        this.nomsMasculins = Arrays.asList("Adran", "Aelar", "Aramil");
        this.nomsFéminins = Arrays.asList("Adrie", "Althaea", "Anastrianna");
        this.nomsFamille = Arrays.asList("Amakiir", "Galanodel", "Liadon");
        this.listeTraits = getTraitsNain();
	}
	
	private List<Trait> getTraitsNain()
	{
		return Arrays.asList(
					new Trait("Augmentation de caractéristiques", "La valeur de constitution augmente de 1."),
					new Trait("Âge", "Les nains deivennent matures au même rythme que les humains, mais on considère qu'ils sont encore jeunes jusqu'à l'âge de 50 ans. Ils vivent en moyenne 350 ans."),
					new Trait("Alignement", "La majorité des nains est d'alignement Loyal et croit profondément aux bienfaits d'une société organisée. Les nains sont plutot attirés vers le bien, ont un sens inné de ce qui est juste et sont convaincus que tout le monde mérite de partager les bienfaits de l'ordre et de la justice."),
					new Trait("Taille", "Les nains mesurent entre 1,20 et 1,50 mètre et pèsent en moyenne 70 kilos. Ils sont de taille Moyenne."),
					new Trait("Vitesse", "La vitesse du nain au sol est de 7.50 mètres. Le nain peut porter une armure lourde snas que cela ne réduise sa vitesse."),
					new Trait("Vision dans le noir", "Habitué à la vie souterraine, le nain a une vision supérieure dans l'obscurité et dans la lumière faible. Dans un rayon de 18 mètres, le nain peut voir dans une zone de lumière faible comme s'il s'agissait d'une lumière vive et dans l'obscurité comme s'il s'agissait d'une lumière faible. Par contre, le nain ne distingue pas les couleurs dans l'obscurité, seulement des nuances de gris."),
					new Trait("Résistance naine", "Le nain a un avantage sur les jets de sauvegarde contre le poison et possède une résistance contre les dégâts de poison."),
					new Trait("Entraînement aux armes elfiques", "Le nain maitrise les haches de guerre, les hachettes, les marteaux légers et les marteaux de guerre."),
					new Trait("Maitrise des outils", "Le nain maitrise un ensemble d'outils d'artisan au choix parmi : outils de forgeron, matériel de brasseur, outils de maçon."),
					new Trait("Connaissance de la pierre", "Quand le nain fait un test d'intelligence (histoire) relatif au travail de la pierre, il considère avoir la maîtrise de la compétence histoire et ajoute le double de son bonus de maitrise au résultat du test au lieu du bonus normal."),
					new Trait("Langues", "Peut parler, lire et écrire le commun et le nain. Le nain est une langue aux consonnes dures et aux sons gutturaux, des spécificités qui se retrouvent dans l'accent qu'ont les nains en parlant un autre langage.")
					);
	}
}
