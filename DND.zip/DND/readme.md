# DND 5th Edition Character Sheet Editor
## Presentation
This project automates and simplifies the creation of a Dungeons & Dragons 5th Edition character sheet. Building a character involves understanding many rules and details, which can sometimes be overwhelming. To streamline this process, the software includes detailed descriptions of all core races in the D&D universe and allows you to automatically apply them to your character sheet. A similar system will be implemented for the character classes as well.

## Classes
### FeuillePersonnage
This class compiles all the individual sections of the character sheet. Each section, such as abilities, traits, and equipment, will be created independently and then assembled into a complete character sheet.

## Races Package
This package contains all the breed definitions available in the core game. Each breed impacts the character's stats and traits. The classes in this package modify the base character sheet to reflect the breed chosen by the user. Each breed will show the features 
of a character of this breed. 

## Classes Package
This package will contain all the classes possible to apply to a character in the core game. 
